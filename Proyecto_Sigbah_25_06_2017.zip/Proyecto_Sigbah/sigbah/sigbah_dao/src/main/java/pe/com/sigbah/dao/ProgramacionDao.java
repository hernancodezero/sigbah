package pe.com.sigbah.dao;

/**
 * @className: ProgramacionDao.java
 * @description: Clase que contiene el consumo de los procedimientos del package BAH_PKG_PROGRAMACION.
 * @date: 21 de jun. de 2017
 * @author: SUMERIO.
 */
public interface ProgramacionDao {

}
